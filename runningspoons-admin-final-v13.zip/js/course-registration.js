// 강의 등록 JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeCourseRegistration();
});

function initializeCourseRegistration() {
    // 6단계 프로세스 초기화
    initializeStepProcess();
    
    // 코스코드 유니크 검증
    initializeCourseCodeValidation();
    
    // 과거 코스 데이터 불러오기
    initializePastCourseLoader();
    
    // AI 기능 초기화
    initializeAIFeatures();
    
    // 폼 유효성 검사 초기화
    initializeFormValidation();
    
    // 저장 버튼 이벤트
    initializeSaveButton();
    
    // 강사 추가 기능
    initializeInstructorAddition();
    
    // 상품 추가 기능
    initializeProductAddition();
    
    // 팝업 기능
    initializePopups();
    
    // AI 자동 제안 기능
    initializeAISuggestions();
    
    // 단계 전환 시 자동 중간저장
    initializeAutoSave();
    
    // 파일 다운로드 기능
    initializeFileDownloads();
    
    // 커리큘럼 파트 추가 기능
    initializeCurriculumPartAddition();
}

// 6단계 프로세스 초기화
function initializeStepProcess() {
    let currentStep = 1;
    const totalSteps = 6;
    
    // 단계 네비게이션 버튼
    const nextBtn = document.getElementById('nextStep');
    const prevBtn = document.getElementById('prevStep');
    
    // 다음 버튼 이벤트
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (validateCurrentStep(currentStep)) {
                if (currentStep < totalSteps) {
                    currentStep++;
                    showStep(currentStep);
                    updateProgress(currentStep, totalSteps);
                    updateNavigationButtons(currentStep, totalSteps);
                }
            }
        });
    }
    
    // 이전 버튼 이벤트
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentStep > 1) {
                currentStep--;
                showStep(currentStep);
                updateProgress(currentStep, totalSteps);
                updateNavigationButtons(currentStep, totalSteps);
            }
        });
    }
    
    // 단계 네비게이션 아이템 클릭 이벤트
    const stepItems = document.querySelectorAll('.step-item');
    stepItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            const stepNumber = index + 1;
            if (stepNumber <= currentStep || stepNumber === 1) {
                currentStep = stepNumber;
                showStep(currentStep);
                updateProgress(currentStep, totalSteps);
                updateNavigationButtons(currentStep, totalSteps);
            }
        });
    });
}

// 현재 단계 표시
function showStep(stepNumber) {
    // 모든 단계 숨기기
    const allSteps = document.querySelectorAll('.step-content');
    allSteps.forEach(step => step.classList.remove('active'));
    
    // 현재 단계 표시
    const currentStepElement = document.getElementById(`step${stepNumber}`);
    if (currentStepElement) {
        currentStepElement.classList.add('active');
    }
    
    // 단계 네비게이션 업데이트
    const stepItems = document.querySelectorAll('.step-item');
    stepItems.forEach((item, index) => {
        item.classList.remove('active', 'completed');
        if (index + 1 === stepNumber) {
            item.classList.add('active');
        } else if (index + 1 < stepNumber) {
            item.classList.add('completed');
        }
    });
}

// 진행률 업데이트
function updateProgress(currentStep, totalSteps) {
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    
    if (progressFill && progressText) {
        const percentage = (currentStep / totalSteps) * 100;
        progressFill.style.width = percentage + '%';
        progressText.textContent = `${currentStep}/${totalSteps} 단계 (${percentage.toFixed(1)}%)`;
    }
}

// 네비게이션 버튼 업데이트
function updateNavigationButtons(currentStep, totalSteps) {
    const nextBtn = document.getElementById('nextStep');
    const prevBtn = document.getElementById('prevStep');
    
    if (prevBtn) {
        prevBtn.style.display = currentStep > 1 ? 'block' : 'none';
    }
    
    if (nextBtn) {
        if (currentStep === totalSteps) {
            nextBtn.textContent = '완료';
            nextBtn.classList.add('btn-success');
        } else {
            nextBtn.textContent = '다음';
            nextBtn.classList.remove('btn-success');
        }
    }
}

// 현재 단계 유효성 검사
function validateCurrentStep(stepNumber) {
    switch(stepNumber) {
        case 1:
            return validateStep1();
        case 2:
            return validateStep2();
        case 3:
            return validateStep3();
        case 4:
            return validateStep4();
        case 5:
            return validateStep5();
        case 6:
            return validateStep6();
        default:
            return true;
    }
}

// 1단계 유효성 검사 (코스 등록)
function validateStep1() {
    const courseMethod = document.getElementById('courseMethod').value;
    const courseName = document.getElementById('courseName').value;
    const courseCode = document.getElementById('courseCode').value;
    const courseManager = document.getElementById('courseManager').value;
    
    if (!courseMethod || !courseName || !courseCode || !courseManager) {
        alert('모든 필수 항목을 입력해주세요.');
        return false;
    }
    
    // 코스코드 유니크 검증
    if (!validateCourseCodeUnique(courseCode)) {
        alert('이미 사용 중인 코스코드입니다.');
        return false;
    }
    
    return true;
}

// 2단계 유효성 검사 (기수 등록)
function validateStep2() {
    const batchName = document.getElementById('batchName').value;
    const batchCode = document.getElementById('batchCode').value;
    const maxStudents = document.getElementById('maxStudents').value;
    const totalSessions = document.getElementById('totalSessions').value;
    const studyPeriod = document.getElementById('studyPeriod').value;
    const instructor = document.getElementById('instructor').value;
    const manager = document.getElementById('manager').value;
    const recruitmentType = document.getElementById('recruitmentType').value;
    const courseDescription = document.getElementById('courseDescription').value;
    
    if (!batchName || !batchCode || !maxStudents || !totalSessions || !studyPeriod || 
        !instructor || !manager || !recruitmentType || !courseDescription) {
        alert('모든 필수 항목을 입력해주세요.');
        return false;
    }
    
    return true;
}

// 3단계 유효성 검사 (커리큘럼)
function validateStep3() {
    const curriculumItems = document.querySelectorAll('.curriculum-item');
    let hasValidItem = false;
    
    curriculumItems.forEach(item => {
        const partName = item.querySelector('input[name="partName"]').value;
        const educationMethod = item.querySelector('select[name="educationMethod"]').value;
        const duration = item.querySelector('input[name="duration"]').value;
        
        if (partName && educationMethod && duration) {
            hasValidItem = true;
        }
    });
    
    if (!hasValidItem) {
        alert('최소 하나의 커리큘럼 파트를 입력해주세요.');
        return false;
    }
    
    return true;
}

// 4단계 유효성 검사 (상품 등록)
function validateStep4() {
    const productItems = document.querySelectorAll('.product-item');
    let hasValidItem = false;
    
    productItems.forEach(item => {
        const productType = item.querySelector('select[name="productType"]').value;
        const productMethod = item.querySelector('select[name="productMethod"]').value;
        const price = item.querySelector('input[name="price"]').value;
        
        if (productType && productMethod && price) {
            hasValidItem = true;
        }
    });
    
    if (!hasValidItem) {
        alert('최소 하나의 상품을 등록해주세요.');
        return false;
    }
    
    return true;
}

// 5단계 유효성 검사 (저장 확인)
function validateStep5() {
    return true; // 5단계는 확인 단계이므로 항상 통과
}

// 6단계 유효성 검사 (상태 결정)
function validateStep6() {
    return true; // 6단계는 선택 단계이므로 항상 통과
}

// 코스코드 유니크 검증 초기화
function initializeCourseCodeValidation() {
    const courseCodeInput = document.getElementById('courseCode');
    if (courseCodeInput) {
        courseCodeInput.addEventListener('blur', validateCourseCodeUnique);
    }
}

// 코스코드 유니크 검증
function validateCourseCodeUnique(courseCode) {
    // 실제로는 서버에서 검증해야 하지만, 여기서는 모의 데이터 사용
    const existingCodes = ['WEB001', 'PYTHON001', 'DATA001', 'REACT001', 'UIUX001'];
    
    if (existingCodes.includes(courseCode)) {
        const validationMsg = document.getElementById('courseCodeValidation');
        if (validationMsg) {
            validationMsg.textContent = '이미 사용 중인 코스코드입니다.';
            validationMsg.style.color = '#dc2626';
        }
        return false;
    } else {
        const validationMsg = document.getElementById('courseCodeValidation');
        if (validationMsg) {
            validationMsg.textContent = '사용 가능한 코스코드입니다.';
            validationMsg.style.color = '#059669';
        }
        return true;
    }
}

// 과거 코스 데이터 불러오기 초기화
function initializePastCourseLoader() {
    const loadPastCourseBtn = document.getElementById('loadPastCourse');
    const pastCourseModal = document.getElementById('pastCourseModal');
    const closeModalBtn = document.getElementById('closePastCourseModal');
    const searchCoursesBtn = document.getElementById('searchCourses');
    
    if (loadPastCourseBtn && pastCourseModal) {
        loadPastCourseBtn.addEventListener('click', () => {
            pastCourseModal.style.display = 'flex';
        });
    }
    
    if (closeModalBtn && pastCourseModal) {
        closeModalBtn.addEventListener('click', () => {
            pastCourseModal.style.display = 'none';
        });
    }
    
    if (searchCoursesBtn) {
        searchCoursesBtn.addEventListener('click', searchPastCourses);
    }
    
    // 모달 외부 클릭 시 닫기
    if (pastCourseModal) {
        pastCourseModal.addEventListener('click', (e) => {
            if (e.target === pastCourseModal) {
                pastCourseModal.style.display = 'none';
            }
        });
    }
}

// 과거 코스 검색
function searchPastCourses() {
    const courseName = document.getElementById('searchCourseName').value;
    const courseCategory = document.getElementById('searchCourseCategory').value;
    const courseCode = document.getElementById('searchCourseCode').value;
    
    // 모의 데이터
    const mockCourses = [
        { id: 1, name: '웹개발 기초 과정', code: 'WEB001', category: 'web', manager: '김개발' },
        { id: 2, name: '파이썬 프로그래밍', code: 'PYTHON001', category: 'data', manager: '이파이썬' },
        { id: 3, name: '데이터 분석 기초', code: 'DATA001', category: 'data', manager: '박데이터' },
        { id: 4, name: 'React 마스터 클래스', code: 'REACT001', category: 'web', manager: '최리액트' },
        { id: 5, name: 'UI/UX 디자인', code: 'UIUX001', category: 'design', manager: '정디자인' }
    ];
    
    // 필터링
    let filteredCourses = mockCourses;
    
    if (courseName) {
        filteredCourses = filteredCourses.filter(course => 
            course.name.includes(courseName)
        );
    }
    
    if (courseCategory) {
        filteredCourses = filteredCourses.filter(course => 
            course.category === courseCategory
        );
    }
    
    if (courseCode) {
        filteredCourses = filteredCourses.filter(course => 
            course.code.includes(courseCode)
        );
    }
    
    // 결과 표시
    displayPastCourses(filteredCourses);
}

// 과거 코스 목록 표시
function displayPastCourses(courses) {
    const courseList = document.getElementById('pastCourseList');
    if (!courseList) return;
    
    if (courses.length === 0) {
        courseList.innerHTML = '<p>검색 결과가 없습니다.</p>';
        return;
    }
    
    courseList.innerHTML = courses.map(course => `
        <div class="past-course-item" onclick="selectPastCourse(${course.id}, '${course.name}', '${course.code}', '${course.manager}')">
            <h4>${course.name}</h4>
            <p>코드: ${course.code} | 담당자: ${course.manager}</p>
        </div>
    `).join('');
}

// 과거 코스 선택
function selectPastCourse(id, name, code, manager) {
    // 선택된 코스 정보를 1단계 폼에 자동 입력
    document.getElementById('courseName').value = name;
    document.getElementById('courseCode').value = code;
    document.getElementById('courseManager').value = manager;
    
    // 모달 닫기
    const pastCourseModal = document.getElementById('pastCourseModal');
    if (pastCourseModal) {
        pastCourseModal.style.display = 'none';
    }
    
    // 코스코드 유니크 검증 실행
    validateCourseCodeUnique(code);
}

// 탭 기능 초기화
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // 모든 탭 버튼 비활성화
            tabButtons.forEach(btn => btn.classList.remove('active'));
            // 모든 탭 콘텐츠 숨기기
            tabContents.forEach(content => content.classList.remove('active'));
            
            // 선택된 탭 활성화
            button.classList.add('active');
            document.getElementById(`${targetTab}-tab`).classList.add('active');
        });
    });
}

// AI 기능 초기화
function initializeAIFeatures() {
    // AI SEO 추천 버튼
    const aiSeoButton = document.getElementById('generateSEO');
    if (aiSeoButton) {
        aiSeoButton.addEventListener('click', generateSEOKeywords);
    }
    
    // AI 코드 미리보기 버튼
    const aiPreviewButton = document.getElementById('generateCode');
    if (aiPreviewButton) {
        aiPreviewButton.addEventListener('click', generateCodePreview);
    }
}

// SEO 키워드 생성
function generateSEOKeywords() {
    const seoTextarea = document.getElementById('seoKeywords');
    const courseName = document.getElementById('courseName').value;
    const courseDescription = document.getElementById('courseDescription').value;
    
    if (!courseName.trim()) {
        showNotification('강의명을 먼저 입력해주세요.', 'warning');
        return;
    }
    
    // 로딩 상태 표시
    const originalText = seoTextarea.value;
    seoTextarea.value = 'AI가 키워드를 분석하고 있습니다...';
    seoTextarea.disabled = true;
    
    // AI 처리 시뮬레이션
    setTimeout(() => {
        const keywords = generateMockSEOKeywords(courseName, courseDescription);
        seoTextarea.value = keywords;
        seoTextarea.disabled = false;
        showNotification('SEO 키워드가 생성되었습니다!', 'success');
    }, 2000);
}

// 코드 미리보기 생성
function generateCodePreview() {
    const courseName = document.getElementById('courseName').value;
    const courseDescription = document.getElementById('courseDescription').value;
    const coursePrice = document.getElementById('coursePrice').value;
    
    if (!courseName.trim() || !courseDescription.trim()) {
        showNotification('강의명과 설명을 모두 입력해주세요.', 'warning');
        return;
    }
    
    // HTML 코드 생성
    const htmlCode = generateMockHTML(courseName, courseDescription, coursePrice);
    document.getElementById('htmlCode').value = htmlCode;
    
    // CSS 코드 생성
    const cssCode = generateMockCSS();
    document.getElementById('cssCode').value = cssCode;
    
    // HTML 탭으로 이동
    document.querySelector('[data-tab="html"]').click();
    
    showNotification('HTML/CSS 코드가 생성되었습니다!', 'success');
}

// 모의 SEO 키워드 생성
function generateMockSEOKeywords(courseName, description) {
    const baseKeywords = [
        courseName,
        `${courseName} 강의`,
        `${courseName} 교육`,
        `${courseName} 학습`,
        `${courseName} 온라인`,
        `${courseName} 수강`,
        `${courseName} 코스`,
        `${courseName} 과정`
    ];
    
    const categoryKeywords = {
        'web': ['웹개발', '프론트엔드', '백엔드', '풀스택', 'HTML', 'CSS', 'JavaScript'],
        'mobile': ['모바일개발', '앱개발', 'iOS', 'Android', 'React Native', 'Flutter'],
        'data': ['데이터분석', '데이터사이언스', 'Python', 'R', 'SQL', '머신러닝'],
        'design': ['UI디자인', 'UX디자인', '그래픽디자인', 'Figma', 'Adobe', '디자인시스템'],
        'ai': ['인공지능', 'AI', '머신러닝', '딥러닝', '데이터사이언스', 'Python']
    };
    
    const category = document.getElementById('courseCategory').value;
    const additionalKeywords = categoryKeywords[category] || [];
    
    return [...baseKeywords, ...additionalKeywords].join(', ');
}

// 모의 HTML 코드 생성
function generateMockHTML(courseName, description, price) {
    const priceFormatted = price ? `₩${parseInt(price).toLocaleString()}` : '₩0';
    
    return `<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${courseName} - 러닝스푼즈</title>
    <meta name="description" content="${description}">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="course-header">
        <div class="container">
            <h1 class="course-title">${courseName}</h1>
            <p class="course-description">${description}</p>
            <div class="course-meta">
                <span class="course-price">${priceFormatted}</span>
                <span class="course-duration">12주 과정</span>
            </div>
        </div>
    </header>
    
    <main class="course-content">
        <div class="container">
            <section class="course-overview">
                <h2>강의 개요</h2>
                <div class="overview-grid">
                    <div class="overview-item">
                        <h3>수강 기간</h3>
                        <p>12주 (3개월)</p>
                    </div>
                    <div class="overview-item">
                        <h3>수강료</h3>
                        <p>${priceFormatted}</p>
                    </div>
                    <div class="overview-item">
                        <h3>난이도</h3>
                        <p>초급</p>
                    </div>
                    <div class="overview-item">
                        <h3>수강생 수</h3>
                        <p>1,000+ 명</p>
                    </div>
                </div>
            </section>
            
            <section class="course-curriculum">
                <h2>커리큘럼</h2>
                <div class="curriculum-list">
                    <div class="curriculum-item">
                        <h3>1주차: ${courseName} 기초</h3>
                        <p>기본 개념과 환경 설정</p>
                    </div>
                    <div class="curriculum-item">
                        <h3>2주차: 핵심 기능 학습</h3>
                        <p>주요 기능과 사용법</p>
                    </div>
                    <div class="curriculum-item">
                        <h3>3주차: 실습 프로젝트</h3>
                        <p>실제 프로젝트를 통한 학습</p>
                    </div>
                </div>
            </section>
        </div>
    </main>
    
    <footer class="course-footer">
        <div class="container">
            <p>&copy; 2024 러닝스푼즈. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>`;
}

// 모의 CSS 코드 생성
function generateMockCSS() {
    return `/* 강의 페이지 스타일 */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.course-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 80px 0;
    text-align: center;
}

.course-title {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 1rem;
}

.course-description {
    font-size: 1.25rem;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto 2rem;
}

.course-meta {
    display: flex;
    justify-content: center;
    gap: 2rem;
    font-size: 1.125rem;
    font-weight: 600;
}

.course-price {
    color: #fbbf24;
}

.course-content {
    padding: 80px 0;
}

.course-overview, .course-curriculum {
    margin-bottom: 60px;
}

.course-overview h2, .course-curriculum h2 {
    font-size: 2rem;
    margin-bottom: 2rem;
    color: #1e293b;
}

.overview-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
}

.overview-item {
    background: #f8fafc;
    padding: 2rem;
    border-radius: 12px;
    text-align: center;
}

.overview-item h3 {
    font-size: 1.125rem;
    color: #64748b;
    margin-bottom: 0.5rem;
}

.overview-item p {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1e293b;
}

.curriculum-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.curriculum-item {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 2rem;
    transition: all 0.3s ease;
}

.curriculum-item:hover {
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.curriculum-item h3 {
    font-size: 1.25rem;
    color: #1e293b;
    margin-bottom: 0.5rem;
}

.curriculum-item p {
    color: #64748b;
}

.course-footer {
    background: #1e293b;
    color: white;
    padding: 2rem 0;
    text-align: center;
}

@media (max-width: 768px) {
    .course-title {
        font-size: 2rem;
    }
    
    .course-meta {
        flex-direction: column;
        gap: 1rem;
    }
    
    .overview-grid {
        grid-template-columns: 1fr;
    }
}`;
}

// 썸네일 업로드 초기화
function initializeThumbnailUpload() {
    const uploadArea = document.getElementById('uploadArea');
    const thumbnailInput = document.getElementById('thumbnailInput');
    const thumbnailPreview = document.getElementById('thumbnailPreview');
    const previewImage = document.getElementById('previewImage');
    const removeThumbnail = document.getElementById('removeThumbnail');
    
    if (!uploadArea || !thumbnailInput) return;
    
    // 업로드 영역 클릭 이벤트
    uploadArea.addEventListener('click', () => {
        thumbnailInput.click();
    });
    
    // 드래그 앤 드롭 이벤트
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#667eea';
        uploadArea.style.background = '#f0f4ff';
    });
    
    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#cbd5e1';
        uploadArea.style.background = '#f8fafc';
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = '#cbd5e1';
        uploadArea.style.background = '#f8fafc';
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileUpload(files[0]);
        }
    });
    
    // 파일 선택 이벤트
    thumbnailInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileUpload(e.target.files[0]);
        }
    });
    
    // 썸네일 제거 이벤트
    if (removeThumbnail) {
        removeThumbnail.addEventListener('click', (e) => {
            e.stopPropagation();
            removeThumbnailPreview();
        });
    }
}

// 파일 업로드 처리
function handleFileUpload(file) {
    // 파일 타입 검증
    if (!file.type.startsWith('image/')) {
        showNotification('이미지 파일만 업로드 가능합니다.', 'error');
        return;
    }
    
    // 파일 크기 검증 (5MB)
    if (file.size > 5 * 1024 * 1024) {
        showNotification('파일 크기는 5MB 이하여야 합니다.', 'error');
        return;
    }
    
    // 파일 미리보기
    const reader = new FileReader();
    reader.onload = (e) => {
        showThumbnailPreview(e.target.result);
    };
    reader.readAsDataURL(file);
}

// 썸네일 미리보기 표시
function showThumbnailPreview(imageSrc) {
    const uploadArea = document.getElementById('uploadArea');
    const thumbnailPreview = document.getElementById('thumbnailPreview');
    const previewImage = document.getElementById('previewImage');
    
    if (previewImage) {
        previewImage.src = imageSrc;
    }
    
    uploadArea.style.display = 'none';
    thumbnailPreview.style.display = 'block';
}

// 썸네일 미리보기 제거
function removeThumbnailPreview() {
    const uploadArea = document.getElementById('uploadArea');
    const thumbnailPreview = document.getElementById('thumbnailPreview');
    const thumbnailInput = document.getElementById('thumbnailInput');
    
    uploadArea.style.display = 'block';
    thumbnailPreview.style.display = 'none';
    thumbnailInput.value = '';
}

// 폼 유효성 검사 초기화
function initializeFormValidation() {
    const inputs = document.querySelectorAll('.input-field, .textarea-field');
    
    inputs.forEach(input => {
        input.addEventListener('blur', () => {
            validateField(input);
        });
        
        input.addEventListener('input', () => {
            clearFieldError(input);
        });
    });
}

// 필드 유효성 검사
function validateField(field) {
    const value = field.value.trim();
    
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, '이 필드는 필수입니다.');
        return false;
    }
    
    if (field.id === 'courseName' && value.length < 2) {
        showFieldError(field, '강의명은 최소 2자 이상이어야 합니다.');
        return false;
    }
    
    if (field.id === 'courseDescription' && value.length < 10) {
        showFieldError(field, '강의 설명은 최소 10자 이상이어야 합니다.');
        return false;
    }
    
    if (field.id === 'coursePrice' && value && (isNaN(value) || parseInt(value) < 0)) {
        showFieldError(field, '올바른 가격을 입력해주세요.');
        return false;
    }
    
    return true;
}

// 필드 에러 표시
function showFieldError(field, message) {
    clearFieldError(field);
    
    field.style.borderColor = '#ef4444';
    field.style.boxShadow = '0 0 0 3px rgba(239, 68, 68, 0.1)';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        color: #ef4444;
        font-size: 0.875rem;
        margin-top: 4px;
    `;
    
    field.parentNode.appendChild(errorDiv);
}

// 필드 에러 제거
function clearFieldError(field) {
    field.style.borderColor = '#e2e8f0';
    field.style.boxShadow = 'none';
    
    const errorDiv = field.parentNode.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

// 저장 버튼 초기화
function initializeSaveButton() {
    const saveButton = document.getElementById('saveCourse');
    if (saveButton) {
        saveButton.addEventListener('click', saveCourse);
    }
}

// 강의 저장
function saveCourse() {
    // 폼 데이터 수집
    const formData = {
        name: document.getElementById('courseName').value.trim(),
        category: document.getElementById('courseCategory').value,
        description: document.getElementById('courseDescription').value.trim(),
        price: parseInt(document.getElementById('coursePrice').value) || 0,
        duration: parseInt(document.getElementById('courseDuration').value) || 0,
        seoKeywords: document.getElementById('seoKeywords').value.trim(),
        htmlCode: document.getElementById('htmlCode').value.trim(),
        cssCode: document.getElementById('cssCode').value.trim(),
        thumbnail: document.getElementById('previewImage')?.src || ''
    };
    
    // 필수 필드 검증
    if (!formData.name || !formData.category || !formData.description) {
        showNotification('필수 항목을 모두 입력해주세요.', 'error');
        return;
    }
    
    // 저장 처리
    const saveButton = document.getElementById('saveCourse');
    saveButton.disabled = true;
    saveButton.textContent = '저장 중...';
    
    // 실제로는 API 호출
    setTimeout(() => {
        console.log('저장된 강의 데이터:', formData);
        
        saveButton.disabled = false;
        saveButton.textContent = '저장하기';
        
        // 성공 모달 표시
        showSuccessModal();
        
        // 폼 초기화
        resetForm();
    }, 1500);
}

// 폼 초기화
function resetForm() {
    document.getElementById('courseName').value = '';
    document.getElementById('courseCategory').value = '';
    document.getElementById('courseDescription').value = '';
    document.getElementById('coursePrice').value = '';
    document.getElementById('courseDuration').value = '';
    document.getElementById('seoKeywords').value = '';
    document.getElementById('htmlCode').value = '';
    document.getElementById('cssCode').value = '';
    
    // 썸네일 초기화
    removeThumbnailPreview();
    
    // HTML 탭으로 이동
    document.querySelector('[data-tab="html"]').click();
}

// 성공 모달 표시
function showSuccessModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.add('show');
    }
}

// 성공 모달 닫기
function closeSuccessModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.remove('show');
    }
}

// 강의 목록 보기
function viewCourseList() {
    closeSuccessModal();
    location.href = 'course-management.html';
}

// 알림 표시
function showNotification(message, type = 'info') {
    // 기존 알림 제거
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // 새 알림 생성
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // 스타일 적용
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '16px 24px',
        borderRadius: '8px',
        color: 'white',
        fontWeight: '500',
        zIndex: '1000',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease',
        maxWidth: '400px',
        wordWrap: 'break-word'
    });
    
    // 타입별 색상
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    
    notification.style.backgroundColor = colors[type] || colors.info;
    
    // DOM에 추가
    document.body.appendChild(notification);
    
    // 애니메이션 표시
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // 자동 제거
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 4000);
}

// 강사 추가 기능 초기화
function initializeInstructorAddition() {
    const addInstructorBtn = document.getElementById('addInstructor');
    if (addInstructorBtn) {
        addInstructorBtn.addEventListener('click', addInstructor);
    }
}

// 강사 추가
function addInstructor() {
    const instructorList = document.getElementById('instructorList');
    if (!instructorList) return;
    
    const instructorCount = instructorList.children.length;
    const instructorId = `instructor_${instructorCount + 1}`;
    
    const instructorItem = document.createElement('div');
    instructorItem.className = 'instructor-item';
    instructorItem.innerHTML = `
        <div class="form-row">
            <div class="form-group">
                <label>강사명 *</label>
                <input type="text" name="instructorName" placeholder="강사명을 입력하세요" class="input-field" required>
            </div>
            <div class="form-group">
                <label>연락처</label>
                <input type="tel" name="instructorPhone" placeholder="연락처를 입력하세요" class="input-field">
            </div>
            <div class="form-group">
                <label>이메일</label>
                <input type="email" name="instructorEmail" placeholder="이메일을 입력하세요" class="input-field">
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <button type="button" class="btn-danger btn-sm" onclick="removeInstructor(this)">삭제</button>
            </div>
        </div>
    `;
    
    instructorList.appendChild(instructorItem);
    
    // 첫 번째 필드에 포커스
    const firstInput = instructorItem.querySelector('input[name="instructorName"]');
    if (firstInput) {
        firstInput.focus();
    }
}

// 강사 삭제
function removeInstructor(button) {
    const instructorItem = button.closest('.instructor-item');
    if (instructorItem) {
        instructorItem.remove();
    }
}

// 상품 추가 기능 초기화
function initializeProductAddition() {
    const addProductBtn = document.getElementById('addProduct');
    if (addProductBtn) {
        addProductBtn.addEventListener('click', addProduct);
    }
}

// 상품 추가
function addProduct() {
    const productList = document.getElementById('productList');
    if (!productList) return;
    
    const productCount = productList.children.length;
    const productId = `product_${productCount + 1}`;
    
    const productItem = document.createElement('div');
    productItem.className = 'product-item';
    productItem.innerHTML = `
        <div class="form-row">
            <div class="form-group">
                <label>상품 타입 *</label>
                <select name="productType" class="input-field" required>
                    <option value="">상품 타입을 선택하세요</option>
                    <option value="regular">정규</option>
                    <option value="special">특별</option>
                    <option value="settlement">정산용</option>
                    <option value="voucher">바우처</option>
                </select>
            </div>
            <div class="form-group">
                <label>상품 방식 *</label>
                <select name="productMethod" class="input-field" required>
                    <option value="">상품 방식을 선택하세요</option>
                    <option value="lump-sum">일시납</option>
                    <option value="installment">할부</option>
                </select>
            </div>
            <div class="form-group">
                <label>가격 *</label>
                <div class="input-with-suffix">
                    <input type="number" name="price" placeholder="0" class="input-field" min="0" required>
                    <span class="input-suffix-inner">원</span>
                </div>
            </div>
            <div class="form-group">
                <label>&nbsp;</label>
                <button type="button" class="btn-danger btn-sm" onclick="removeProduct(this)">삭제</button>
            </div>
        </div>
        <div class="form-group">
            <label>비고 (내부 메모)</label>
            <input type="text" name="memo" placeholder="내부 메모를 입력하세요" class="input-field">
        </div>
    `;
    
    productList.appendChild(productItem);
    
    // 첫 번째 필드에 포커스
    const firstSelect = productItem.querySelector('select[name="productType"]');
    if (firstSelect) {
        firstSelect.focus();
    }
}

// 상품 삭제
function removeProduct(button) {
    const productItem = button.closest('.product-item');
    if (productItem) {
        productItem.remove();
    }
}

// 팝업 기능 초기화
function initializePopups() {
    // Step 5 저장 버튼들
    const saveAndContinueBtn = document.getElementById('saveAndContinue');
    const tempSaveBtn = document.getElementById('tempSave');
    
    if (saveAndContinueBtn) {
        saveAndContinueBtn.addEventListener('click', () => {
            showPopup('임시저장완료');
        });
    }
    
    if (tempSaveBtn) {
        tempSaveBtn.addEventListener('click', () => {
            showPopup('임시저장완료');
        });
    }
    
    // Step 6 버튼들
    const finalTempSaveBtn = document.getElementById('tempSaveFinal');
    const finalRegisterBtn = document.getElementById('finalRegister');
    const completeBtn = document.getElementById('completeBtn');
    
    if (finalTempSaveBtn) {
        finalTempSaveBtn.addEventListener('click', () => {
            showPopup('임시저장됐습니다');
        });
    }
    
    if (finalRegisterBtn) {
        finalRegisterBtn.addEventListener('click', () => {
            showPopup('최종등록 완료입니다');
        });
    }
    
    if (completeBtn) {
        completeBtn.addEventListener('click', () => {
            showPopup('강의 등록 완료');
            // 2초 후 대시보드로 이동
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 2000);
        });
    }
}

// 팝업 표시
function showPopup(message) {
    // 기존 팝업 제거
    const existingPopup = document.querySelector('.popup-modal');
    if (existingPopup) {
        existingPopup.remove();
    }
    
    // 새 팝업 생성
    const popup = document.createElement('div');
    popup.className = 'popup-modal';
    popup.innerHTML = `
        <div class="popup-content">
            <div class="popup-message">${message}</div>
            <button class="btn-primary" onclick="closePopup()">확인</button>
        </div>
    `;
    
    // 스타일 적용
    popup.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 3000;
    `;
    
    const popupContent = popup.querySelector('.popup-content');
    popupContent.style.cssText = `
        background: white;
        padding: 2rem;
        border-radius: 12px;
        text-align: center;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        max-width: 400px;
        width: 90%;
    `;
    
    const popupButton = popup.querySelector('.btn-primary');
    popupButton.style.cssText = `
        margin: 0 auto;
        display: block;
    `;
    
    const popupMessage = popup.querySelector('.popup-message');
    popupMessage.style.cssText = `
        font-size: 1.125rem;
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 1.5rem;
    `;
    
    document.body.appendChild(popup);
    
    // 1.5초 후 자동 닫기
    setTimeout(() => {
        closePopup();
    }, 1500);
}

// 팝업 닫기
function closePopup() {
    const popup = document.querySelector('.popup-modal');
    if (popup) {
        popup.remove();
    }
}

// AI 자동 제안 기능 초기화
function initializeAISuggestions() {
    // Step 2 AI 제안
    const aiSuggestStep2 = document.getElementById('aiSuggestStep2');
    if (aiSuggestStep2) {
        aiSuggestStep2.addEventListener('click', () => {
            suggestStep2Fields();
        });
    }
    
    // Step 3 AI 제안
    const aiSuggestStep3 = document.getElementById('aiSuggestStep3');
    if (aiSuggestStep3) {
        aiSuggestStep3.addEventListener('click', () => {
            suggestStep3Fields();
        });
    }
    
    // Step 4 AI 제안
    const aiSuggestStep4 = document.getElementById('aiSuggestStep4');
    if (aiSuggestStep4) {
        aiSuggestStep4.addEventListener('click', () => {
            suggestStep4Fields();
        });
    }
    
    // Step 5 AI 제안
    const aiSuggestStep5 = document.getElementById('aiSuggestStep5');
    if (aiSuggestStep5) {
        aiSuggestStep5.addEventListener('click', () => {
            suggestStep5Fields();
        });
    }
}

// Step 2 필드 자동 채움
function suggestStep2Fields() {
    if (confirm('기존에 입력된 값이 있다면 덮어쓰게 됩니다. 계속하시겠습니까?')) {
        // 기수명 자동 제안
        const batchName = document.getElementById('batchName');
        if (batchName && !batchName.value) {
            batchName.value = '1기 (2025년 1월)';
        }
        
        // 난이도 자동 선택
        const difficultyCheckboxes = document.querySelectorAll('input[name="difficulty"]');
        if (difficultyCheckboxes.length > 0) {
            difficultyCheckboxes[0].checked = true; // 입문 선택
        }
        
        // 정원 자동 입력
        const capacity = document.getElementById('capacity');
        if (capacity && !capacity.value) {
            capacity.value = '30';
        }
        
        // 총 회차 자동 입력
        const totalSessions = document.getElementById('totalSessions');
        if (totalSessions && !totalSessions.value) {
            totalSessions.value = '12';
        }
        
        // 수강기한 자동 입력
        const studyPeriod = document.getElementById('studyPeriod');
        if (studyPeriod && !studyPeriod.value) {
            studyPeriod.value = '90';
        }
        
        showNotification('Step 2 필드가 자동으로 채워졌습니다.', 'success');
    }
}

// Step 3 필드 자동 채움
function suggestStep3Fields() {
    if (confirm('기존에 입력된 값이 있다면 덮어쓰게 됩니다. 계속하시겠습니까?')) {
        // 커리큘럼 자동 추가
        const curriculumList = document.getElementById('curriculumList');
        if (curriculumList) {
            const curriculumItems = curriculumList.querySelectorAll('.curriculum-item');
            if (curriculumItems.length === 0) {
                // 기본 커리큘럼 추가
                addCurriculumItem('1. 오리엔테이션', '강의', '2시간', '강의 소개 및 환경 설정');
                addCurriculumItem('2. 기초 이론', '강의', '3시간', '핵심 개념 학습');
                addCurriculumItem('3. 실습', '프로젝트', '4시간', '실제 프로젝트 진행');
            }
        }
        
        showNotification('Step 3 필드가 자동으로 채워졌습니다.', 'success');
    }
}

// Step 4 필드 자동 채움
function suggestStep4Fields() {
    if (confirm('기존에 입력된 값이 있다면 덮어쓰게 됩니다. 계속하시겠습니까?')) {
        // 상품 자동 추가
        const productList = document.getElementById('productList');
        if (productList) {
            const productItems = productList.querySelectorAll('.product-item');
            if (productItems.length === 0) {
                addProduct();
                // 첫 번째 상품 필드 자동 채움
                const firstProduct = productList.querySelector('.product-item');
                if (firstProduct) {
                    const productType = firstProduct.querySelector('select[name="productType"]');
                    const productMethod = firstProduct.querySelector('select[name="productMethod"]');
                    const price = firstProduct.querySelector('input[name="price"]');
                    
                    if (productType) productType.value = 'regular';
                    if (productMethod) productMethod.value = 'lump-sum';
                    if (price) price.value = '150000';
                }
            }
        }
        
        showNotification('Step 4 필드가 자동으로 채워졌습니다.', 'success');
    }
}

// Step 5 필드 자동 채움
function suggestStep5Fields() {
    if (confirm('기존에 입력된 값이 있다면 덮어쓰게 됩니다. 계속하시겠습니까?')) {
        // 오류 확인 및 자동 수정
        validateAllSteps();
        showNotification('Step 5 필드가 자동으로 채워졌습니다.', 'success');
    }
}

// 커리큘럼 아이템 추가 (Step 3용)
function addCurriculumItem(partName, method, time, details) {
    const curriculumList = document.getElementById('curriculumList');
    if (!curriculumList) return;
    
    const curriculumItem = document.createElement('div');
    curriculumItem.className = 'curriculum-item';
    curriculumItem.innerHTML = `
        <div class="form-row">
            <div class="form-group">
                <label>파트명 *</label>
                <input type="text" name="partName" placeholder="파트명을 입력하세요" class="input-field" value="${partName}" required>
            </div>
            <div class="form-group">
                <label>교육방식 *</label>
                <select name="method" class="input-field" required>
                    <option value="">교육방식을 선택하세요</option>
                    <option value="lecture" ${method === '강의' ? 'selected' : ''}>강의</option>
                    <option value="bootcamp" ${method === '부트캠프' ? 'selected' : ''}>부트캠프</option>
                    <option value="project" ${method === '프로젝트' ? 'selected' : ''}>프로젝트</option>
                </select>
            </div>
            <div class="form-group">
                <label>시간 *</label>
                <input type="text" name="time" placeholder="시간을 입력하세요" class="input-field" value="${time}" required>
            </div>
        </div>
        <div class="form-group">
            <label>세부내용 *</label>
            <textarea name="details" placeholder="세부내용을 입력하세요" class="textarea-field" rows="3" required>${details}</textarea>
        </div>
        <div class="form-group">
            <label>비고</label>
            <input type="text" name="notes" placeholder="비고를 입력하세요" class="input-field">
        </div>
    `;
    
    curriculumList.appendChild(curriculumItem);
}

// 모든 단계 유효성 검사
function validateAllSteps() {
    // 간단한 유효성 검사 로직
    const requiredFields = document.querySelectorAll('input[required], select[required], textarea[required]');                                                                                                          
    let hasErrors = false;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = '#ef4444';
            hasErrors = true;
        } else {
            field.style.borderColor = '#e2e8f0';
        }
    });
    
    if (hasErrors) {
        showNotification('일부 필수 필드가 비어있습니다. 확인해주세요.', 'warning');
    } else {
        showNotification('모든 필드가 올바르게 입력되었습니다.', 'success');
    }
}

// 자동 중간저장 기능 초기화
function initializeAutoSave() {
    // 다음 버튼들에 자동저장 이벤트 추가
    const nextButtons = document.querySelectorAll('.next-btn');
    nextButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // 기본 동작 전에 중간저장 실행
            setTimeout(() => {
                saveCurrentStep();
            }, 100);
        });
    });
}

// 현재 단계 데이터 중간저장
function saveCurrentStep() {
    try {
        const currentStep = getCurrentStep();
        const stepData = collectStepData(currentStep);
        
        // 로컬 스토리지에 저장
        localStorage.setItem(`courseRegistration_step${currentStep}`, JSON.stringify(stepData));
        
        // 성공 알림
        showAutoSaveNotification();
    } catch (error) {
        console.error('중간저장 실패:', error);
        showErrorNotification('중간저장에 실패했습니다.');
    }
}

// 현재 단계 번호 가져오기
function getCurrentStep() {
    const activeStep = document.querySelector('.step.active');
    if (activeStep) {
        return parseInt(activeStep.dataset.step) || 1;
    }
    return 1;
}

// 현재 단계의 데이터 수집
function collectStepData(step) {
    const data = {};
    
    switch(step) {
        case 1:
            // 코스 등록 데이터
            data.courseType = document.querySelector('input[name="courseType"]:checked')?.value || '';
            data.courseName = document.querySelector('input[name="courseName"]')?.value || '';
            data.courseCode = document.querySelector('input[name="courseCode"]')?.value || '';
            data.manager = document.querySelector('input[name="manager"]')?.value || '';
            break;
        case 2:
            // 기수 등록 데이터
            data.batchName = document.querySelector('input[name="batchName"]')?.value || '';
            data.batchCode = document.querySelector('input[name="batchCode"]')?.value || '';
            data.difficulty = Array.from(document.querySelectorAll('input[name="difficulty"]:checked')).map(cb => cb.value);
            data.capacity = document.querySelector('input[name="capacity"]')?.value || '';
            data.totalSessions = document.querySelector('input[name="totalSessions"]')?.value || '';
            data.duration = document.querySelector('input[name="duration"]')?.value || '';
            data.startDate = document.querySelector('input[name="startDate"]')?.value || '';
            data.endDate = document.querySelector('input[name="endDate"]')?.value || '';
            data.time = document.querySelector('input[name="time"]')?.value || '';
            break;
        case 3:
            // 커리큘럼 데이터
            data.curriculum = [];
            const curriculumItems = document.querySelectorAll('.curriculum-item');
            curriculumItems.forEach(item => {
                data.curriculum.push({
                    partName: item.querySelector('input[name="partName"]')?.value || '',
                    educationMethod: item.querySelector('select[name="educationMethod"]')?.value || '',
                    time: item.querySelector('input[name="time"]')?.value || '',
                    description: item.querySelector('textarea[name="description"]')?.value || '',
                    note: item.querySelector('input[name="note"]')?.value || ''
                });
            });
            break;
        case 4:
            // 상품 등록 데이터
            data.products = [];
            const productItems = document.querySelectorAll('.product-item');
            productItems.forEach(item => {
                data.products.push({
                    productType: item.querySelector('select[name="productType"]')?.value || '',
                    paymentMethod: item.querySelector('select[name="paymentMethod"]')?.value || '',
                    price: item.querySelector('input[name="price"]')?.value || '',
                    note: item.querySelector('input[name="note"]')?.value || ''
                });
            });
            break;
        case 5:
            // 저장 및 오류 확인 데이터
            data.errors = [];
            const errorFields = document.querySelectorAll('.error-field');
            errorFields.forEach(field => {
                data.errors.push({
                    field: field.name,
                    message: field.dataset.errorMessage || ''
                });
            });
            break;
    }
    
    return data;
}

// 자동저장 알림 표시
function showAutoSaveNotification() {
    // 기존 알림 제거
    const existingNotification = document.querySelector('.auto-save-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // 새 알림 생성
    const notification = document.createElement('div');
    notification.className = 'auto-save-notification';
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">💾</span>
            <span class="notification-text">중간저장됐습니다</span>
        </div>
    `;
    
    // 스타일 적용
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 2000;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    const notificationContent = notification.querySelector('.notification-content');
    notificationContent.style.cssText = `
        display: flex;
        align-items: center;
        gap: 8px;
    `;
    
    document.body.appendChild(notification);
    
    // 2초 후 자동 제거
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 2000);
}

// 에러 알림 표시
function showErrorNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'error-notification';
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">❌</span>
            <span class="notification-text">${message}</span>
        </div>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #ef4444;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 2000;
        font-size: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 8px;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    // 3초 후 자동 제거
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// 파일 다운로드 기능 초기화
function initializeFileDownloads() {
    // 커리큘럼 다운로드
    const downloadCurriculumBtn = document.getElementById('downloadCurriculum');
    if (downloadCurriculumBtn) {
        downloadCurriculumBtn.addEventListener('click', downloadCurriculumCSV);
    }
    
    // 상품 다운로드
    const downloadProductsBtn = document.getElementById('downloadProducts');
    if (downloadProductsBtn) {
        downloadProductsBtn.addEventListener('click', downloadProductsCSV);
    }
}

// 커리큘럼 CSV 다운로드
function downloadCurriculumCSV() {
    const curriculumItems = document.querySelectorAll('.curriculum-item');
    const data = [];
    
    curriculumItems.forEach((item, index) => {
        const partName = item.querySelector('input[name="partName"]')?.value || '';
        const educationMethod = item.querySelector('select[name="educationMethod"]')?.value || '';
        const time = item.querySelector('input[name="time"]')?.value || '';
        const description = item.querySelector('textarea[name="description"]')?.value || '';
        const note = item.querySelector('input[name="note"]')?.value || '';
        
        if (partName || educationMethod || time || description || note) {
            data.push({
                '순번': index + 1,
                '파트명': partName,
                '교육방식': educationMethod,
                '시간': time,
                '세부내용': description,
                '비고': note
            });
        }
    });
    
    if (data.length === 0) {
        showNotification('다운로드할 커리큘럼 데이터가 없습니다.', 'warning');
        return;
    }
    
    downloadCSV(data, '커리큘럼');
}

// 상품 CSV 다운로드
function downloadProductsCSV() {
    const productItems = document.querySelectorAll('.product-item');
    const data = [];
    
    productItems.forEach((item, index) => {
        const productType = item.querySelector('select[name="productType"]')?.value || '';
        const paymentMethod = item.querySelector('select[name="paymentMethod"]')?.value || '';
        const price = item.querySelector('input[name="price"]')?.value || '';
        const note = item.querySelector('input[name="note"]')?.value || '';
        
        if (productType || paymentMethod || price || note) {
            data.push({
                '순번': index + 1,
                '상품타입': productType,
                '상품방식': paymentMethod,
                '가격': price,
                '비고': note
            });
        }
    });
    
    if (data.length === 0) {
        showNotification('다운로드할 상품 데이터가 없습니다.', 'warning');
        return;
    }
    
    downloadCSV(data, '상품목록');
}

// CSV 다운로드 공통 함수
function downloadCSV(data, filename) {
    if (data.length === 0) return;
    
    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row => 
            headers.map(header => `"${row[header] || ''}"`).join(',')
        )
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showNotification(`${filename} 파일이 다운로드되었습니다.`, 'success');
}

// 커리큘럼 파트 추가 기능 초기화
function initializeCurriculumPartAddition() {
    const addPartBtn = document.getElementById('addCurriculumPart');
    if (addPartBtn) {
        addPartBtn.addEventListener('click', addCurriculumPart);
    }
}

// 커리큘럼 파트 추가
function addCurriculumPart() {
    const curriculumList = document.getElementById('curriculumList');
    if (!curriculumList) return;
    
    const newPart = document.createElement('div');
    newPart.className = 'curriculum-item';
    newPart.innerHTML = `
        <div class="form-row">
            <div class="form-group">
                <label>파트명 *</label>
                <input type="text" name="partName" placeholder="파트명을 입력하세요" class="input-field" required>
            </div>
            <div class="form-group">
                <label>교육방식 *</label>
                <select name="educationMethod" class="input-field" required>
                    <option value="">교육방식을 선택하세요</option>
                    <option value="lecture">강의</option>
                    <option value="bootcamp">부트캠프</option>
                    <option value="project">프로젝트</option>
                </select>
            </div>
            <div class="form-group">
                <label>시간 *</label>
                <div class="input-with-suffix">
                    <input type="number" name="time" placeholder="시간을 입력하세요" class="input-field" min="1" required>
                    <span class="input-suffix-inner">시간</span>
                </div>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>세부내용</label>
                <textarea name="details" placeholder="세부내용을 입력하세요" class="textarea-field" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>비고</label>
                <input type="text" name="note" placeholder="비고를 입력하세요" class="input-field">
            </div>
        </div>
        <div class="form-actions">
            <button type="button" class="btn-danger btn-sm" onclick="removeCurriculumPart(this)">삭제</button>
        </div>
    `;
    
    curriculumList.appendChild(newPart);
    
    // 새로 추가된 파트의 첫 번째 입력 필드에 포커스
    const firstInput = newPart.querySelector('input[name="partName"]');
    if (firstInput) {
        firstInput.focus();
    }
}

// 커리큘럼 파트 삭제
function removeCurriculumPart(button) {
    const curriculumItem = button.closest('.curriculum-item');
    if (curriculumItem) {
        curriculumItem.remove();
    }
}
